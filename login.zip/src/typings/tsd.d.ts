/// <reference path="../../node_modules/angular2/bundles/typings/angular2/angular2.d.ts" />
/// <reference path="../../node_modules/angular2/bundles/typings/angular2/http.d.ts" />
/// <reference path="../../node_modules/angular2/bundles/typings/angular2/router.d.ts" />
