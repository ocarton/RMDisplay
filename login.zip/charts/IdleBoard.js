/// <reference path="../typings/angular2/angular2.d.ts"/>
angular.module('IdleBoard', ['as.sortable'])

.controller( 'IdleCtrl', function IdleController( $scope, auth, $http, $location, store) {



});
