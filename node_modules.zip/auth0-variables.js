var AUTH0_CLIENT_ID='DoSDUdFuDMBT70SDScOUL2ZrHGjL1Sex'; 
var AUTH0_DOMAIN='ocarton.eu.auth0.com'; 
var AUTH0_CALLBACK_URL=location.href;